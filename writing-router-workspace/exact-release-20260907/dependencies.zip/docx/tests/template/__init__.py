"""Template workflow regression tests."""
