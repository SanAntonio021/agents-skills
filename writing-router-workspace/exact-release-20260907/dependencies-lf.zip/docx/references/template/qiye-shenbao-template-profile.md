# Word Template Profile

- Template source: public repo ships the style profile only; original sample document omitted.
- Generated: `2026-03-18T03:12:57.164636+00:00`
- Styles captured: `19`

## Page Setup

| Rule | Value |
| --- | --- |
| Page size | 595.3 pt (8.27 in) x 841.9 pt (11.69 in) |
| Margins | top 72 pt (1.00 in), bottom 72 pt (1.00 in), left 90 pt (1.25 in), right 90 pt (1.25 in) |
| Header distance | 42.55 pt (0.59 in) |
| Footer distance | 49.6 pt (0.69 in) |
| Orientation | 0 |

## Recommended Style Map

| Role | Style |
| --- | --- |
| body | 正文 |
| body_text | 正文文本 |
| caption | 题注 |
| heading_1 | 标题 1 |
| heading_2 | 标题 2 |
| heading_3 | 标题 3 |
| heading_4 | 标题 4 |
| heading_5 | 标题 5 |
| heading_6 | 标题 6 |
| heading_7 | 标题 7 |
| heading_8 | 标题 8 |
| heading_9 | 标题 9 |
| list_paragraph | 列表段落 |
| normal | 正文 |
| subtitle | 副标题 |
| title | 标题 |
| toc_1 | TOC 1 |
| toc_2 | TOC 2 |
| toc_3 | TOC 3 |

## Styles

### TOC 1

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri, 10.5pt
- Paragraph: align=3, before=0pt, after=0pt, lineRule=0, line=12pt, firstLine=0pt

### TOC 2

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri, 10.5pt
- Paragraph: align=3, before=0pt, after=0pt, lineRule=0, line=12pt, firstLine=0pt

### TOC 3

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri, 10.5pt
- Paragraph: align=3, before=0pt, after=0pt, lineRule=0, line=12pt, firstLine=0pt

### 列表段落

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri, 10.5pt
- Paragraph: align=3, before=0pt, after=0pt, lineRule=0, line=12pt, firstLine=21pt

### 副标题

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri, 16pt, bold
- Paragraph: align=1, before=12pt, after=3pt, lineRule=5, line=15.6pt, firstLine=0pt

### 标题

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri Light, 16pt, bold
- Paragraph: align=1, before=12pt, after=3pt, lineRule=0, line=12pt, firstLine=0pt

### 标题 1

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri, 22pt, bold
- Paragraph: align=3, before=17pt, after=16.5pt, lineRule=5, line=28.9pt, firstLine=0pt

### 标题 2

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri Light, 16pt, bold
- Paragraph: align=3, before=13pt, after=13pt, lineRule=5, line=20.8pt, firstLine=0pt

### 标题 3

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: 宋体, 13.5pt, bold
- Paragraph: align=0, before=0pt, after=0pt, lineRule=0, line=12pt, firstLine=0pt

### 标题 4

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri Light, 14pt, bold
- Paragraph: align=3, before=14pt, after=14.5pt, lineRule=5, line=18.8pt, firstLine=0pt

### 标题 5

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri, 14pt, bold
- Paragraph: align=3, before=14pt, after=14.5pt, lineRule=5, line=18.8pt, firstLine=0pt

### 标题 6

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri Light, 12pt, bold
- Paragraph: align=3, before=12pt, after=3.2pt, lineRule=5, line=16pt, firstLine=0pt

### 标题 7

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri, 12pt, bold
- Paragraph: align=3, before=12pt, after=3.2pt, lineRule=5, line=16pt, firstLine=0pt

### 标题 8

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri Light, 12pt
- Paragraph: align=3, before=12pt, after=3.2pt, lineRule=5, line=16pt, firstLine=0pt

### 标题 9

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri Light, 10.5pt
- Paragraph: align=3, before=12pt, after=3.2pt, lineRule=5, line=16pt, firstLine=0pt

### 正文

- Type: `paragraph`
- Built-in: `True`
- Base style: `-`
- Next style: `正文`
- Font: Calibri, 10.5pt
- Paragraph: align=3, before=0pt, after=0pt, lineRule=0, line=12pt, firstLine=0pt

### 正文文本

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `引文目录标题`
- Font: Calibri, 10.5pt
- Paragraph: align=3, before=0pt, after=6pt, lineRule=0, line=12pt, firstLine=0pt

### 题注

- Type: `paragraph`
- Built-in: `True`
- Base style: `正文`
- Next style: `正文`
- Font: Calibri Light, 10pt
- Paragraph: align=3, before=0pt, after=0pt, lineRule=0, line=12pt, firstLine=0pt

### 公文处理助手-正文样式

- Type: `paragraph`
- Built-in: `False`
- Base style: `-`
- Next style: `公文处理助手-正文样式`
- Font: Times New Roman, 16pt
- Paragraph: align=3, before=0pt, after=0pt, lineRule=4, line=29.05pt, firstLine=32pt
