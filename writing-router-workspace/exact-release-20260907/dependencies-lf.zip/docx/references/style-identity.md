# Style identity audit and remap

Use this workflow when an existing DOCX must keep its original Word style names, or when parallel
AI-created styles must be consolidated into identities already present in a named template.

## Content-edit audit

Keep the pre-edit DOCX as the baseline. After changing content, run:

```powershell
python scripts/style_guard.py audit `
  --baseline C:\path\before.docx `
  --candidate C:\path\after.docx `
  --json-out C:\path\style-audit.json
```

Default behavior is strict. Exit code `1` means the edit introduced at least one unauthorized style
change. The JSON report separates:

- added, removed, or modified style definitions;
- paragraph style changes;
- paragraph/run direct-formatting drift;
- newly orphaned styles;
- new references to missing styles.

Do not use `--report-only` in a delivery gate. It is for diagnosis only. If the user explicitly
approved a formatting change, modify the existing style definition and repeat
`--allow-style-change StyleId`. Do not authorize a newly created parallel style.

## Target selection preflight

Before writing a mapping, inventory all candidate paragraph styles in the named template. Record
each style ID, OOXML `w:name`, `basedOn`, `next`, and paragraph usage count. Match the exact identity
the user named; prefixes and similar formatting do not make styles interchangeable. In particular,
`正文` is not `00正文`, and `公式` is not `00公式`.

Word localizes built-in style names. A style displayed as `正文` in Chinese Word can be stored as
`w:name="Normal"`; headings and captions can likewise use English OOXML names. If the requested UI
name is not explicit in OOXML, report the built-in mapping separately or, with current-task Office
COM isolation, inspect `NameLocal` through the shared guard. Never choose a prefixed custom style
merely because its XML name is easier to recognize.

## Explicit identity remap

`remap` takes layout properties from each old style, but takes the target style ID, localized name,
and UI metadata from the named template. It rewrites style references throughout Word XML parts,
sets the requested next-paragraph styles, then removes the old definitions.

```powershell
python scripts/style_guard.py remap `
  --input C:\path\input.docx `
  --template C:\path\style-source.docx `
  --output C:\path\output.docx `
  --map OldBody=TemplateBodyId `
  --map OldHeading=TemplateHeadingId `
  --next-style TemplateBodyId=TemplateBodyId `
  --next-style TemplateHeadingId=TemplateBodyId `
  --json-out C:\path\remap-report.json
```

That default is identity-only repair: input layout remains visually unchanged. When the user wants
the template's actual font, size, spacing, indentation, and alignment instead, add:

```powershell
  --format-source template
```

Template-format mode can change pagination. It keeps only the mapped template paragraph styles and
removes their linked character-style relationships, because those helper IDs commonly collide with
unrelated character styles in the input DOCX. It also removes style-level `numPr`, because numbering
IDs are package-local; importing one without its template numbering table can create unrelated
bullets or numbers. Paragraph-level numbering and `word/numbering.xml` remain unchanged. The mode
does not clear run-level direct formatting; audit mapped paragraphs first and remove only verified
conflicts, preserving intentional emphasis, subscript, superscript, and equation formatting.

The output path must not exist. Mappings must be one-to-one, every old style must exist in the input,
and every target style must exist in the template. The tool rejects chained mappings.

## Acceptance boundary

The remap report proves that paragraph count, body/formula text tokens, OMML structure, media,
relationships, and non-style XML structure stayed unchanged. It also reports whether numbering bytes
changed. For a job that requires numbering to remain byte-identical, treat
`numbering_unchanged=false` as a hard failure.

Ordinary paragraph updates use the fast content/style checks in `SKILL.md` and do not automatically
render. For remaps that change typography, template layout or pagination, or an explicit layout-check
request, render through a suitable guarded renderer and inspect the affected pages and pagination
boundaries. Inspect all pages for document-wide changes; render the baseline as well only when needed
for comparison. On Windows, LibreOffice rendering must use `libreoffice-runner`.
If the user approved Word COM for the current task, test `NameLocal`, Enter-key inheritance, and style
count in an isolated copy through the shared COM guard. Never connect to an existing Word process.
