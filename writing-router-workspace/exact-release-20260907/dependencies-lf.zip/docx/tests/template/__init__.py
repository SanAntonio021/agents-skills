"""Template workflow regression tests."""
