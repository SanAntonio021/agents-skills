---
name: project-writing
description: 中文工程项目书、申请书正文、专家答复和终稿审校。Use when 任务涉及工程申报、工程建设、产业化应用、研发需求、技术指标、专家意见回复或项目书定稿；根据 proposal、expert_reply、final_audit 三种模式处理，不把固定三段式当作默认模板。
---

# 工程项目写作

## 入口

从 [writing-router](../writing-router/SKILL.md) 接收：

- `document_type=project`
- `mode=proposal|expert_reply|final_audit`
- `edit_scope`、`language`、`loaded_refs`

建立或沿用写作上下文后、处理正文前，读取[文稿协作](../writing-router/references/collaborative-writing.md)，按其中的范围和例外选择处理方式，并将实际路径记入 `loaded_refs`。直接调用本技能时同样执行；本轮已读且处理方式未变时沿用。

读取 [共同质量规则](../writing-router/references/common-quality.md)。完整草稿、结构重写、终稿审校和只审不改任务再读取 [AI 气味目录](../writing-router/references/ai-smell-catalog.md)。

私有样稿为 `D:\BaiduSyncdisk\.agents\writing-samples\project-writing.md`；只读取 `status: approved` 的正文，候选区不作为写作依据。公开的本技能不保存个人项目样稿。

## `proposal`

先锁定申报表栏目、字数、评价对象和事实来源，再决定结构。常用的信息链包括：

- 要解决的工程问题和使用场景；
- 建设或研发对象；
- 实现方法、关键接口和适配条件；
- 可考核指标与验证方法；
- 已有基础、部署约束和风险边界。

这些是可选职责，不是固定章节。栏目已规定时按栏目写；短段落只保留完成该栏目所需的职责。成果简介确需三段式时可以使用，但不得为了凑三段重复同一结论。

工程表述应明确“任务—能力—适配对象—真实约束”。“卡点”写当前能力缺口及其后果；“研发需求”写要形成的能力和验收条件，不提前宣称已经突破。

## `expert_reply`

逐条处理专家真正问的问题：

1. 先给明确答复或判断；
2. 写支撑答复的事实、数据、计算或已有工作；
3. 说明正文将改在哪里、改成什么口径；
4. 仍缺证据时直说缺哪一项，不用礼貌套话或防御性长段落代替证据。

若模板要求“意见—回复—修改位置”，保留模板。没有模板时不强制三栏或三段。专家原话、指标和否定范围属于受保护内容。

## `final_audit`

按共同质量规则分点报告终稿问题，重点检查：

- 同一任务、指标或价值判断是否跨栏目无理由重复；
- 拟开展、已设计、已实现、已测试和已应用是否与证据一致；
- 技术指标是否写清对象、条件、单位、测量或计算方法；
- 项目价值是否有应用对象、现有差距或量化效果支撑；
- 专家答复与正文修改是否一致；
- 模板必填项、字数和固定标题是否保留。

任何数字漂移、公式含义变化、状态升级或跨节矛盾都判 `fail`。

## 公式和指标

公式旁边说明每个变量、单位和取值来源，并用一句话解释公式在工程上用来判断什么。计算值要区分输入、假设、计算方法和结果；仿真、台架测试、外场实测不得混写。

核心任务是论证指标是否可行时转 `target-feasibility`。本技能负责把核验后的结论放回正确栏目。

## 用词与样式

- 用具体对象、动作、条件和结果替代空泛评价。
- 术语保持稳定，不为避重轮换“系统、平台、装置、载体”。
- 可以写项目必要性和价值，但结论强度必须由差距、场景、指标或验证支撑。
- 起草或精修时读取 `D:\BaiduSyncdisk\.agents\vocab\中文\通用.md` 和 `D:\BaiduSyncdisk\.agents\vocab\中文\申报书.md`；交付前用 `style-vocab` 做软审计，命中项仍结合文体例外判断。
- 黑障或高超声速通信术语按需读取 [专门术语表](references/engineering-glossary-blackout.md)。

## 文件边界

正文按当前协作方式写回主稿，飞书主稿交给对应平台技能局部更新。实际写入本地 `.md` 或 `.tex` 前，执行 [文稿版本保护](../writing-router/references/document-version-protection.md)。Word 交付先执行 [Markdown 到 DOCX 交接契约](../writing-router/references/markdown-docx-contract.md)，使用本轮按协作方式处理并审校的正文交给 `docx`，默认另存新文件；不在导出时再做通用风格改写。

## 完成条件

- 每个栏目只承担模板要求的功能；
- 任务、能力、适配对象和约束说清楚；
- 指标、公式、变量、单位和状态可回查；
- 必要复述有不同栏目功能，无整段复制；
- `loaded_refs` 只包含实际读取文件。
