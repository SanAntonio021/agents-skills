> **How to use this file**: it is a catalog of smells, not a checklist to run top to bottom. The principles in `SKILL.md` Core Stance apply here too: over-editing is failure, the author's voice and genre win, and these lists are examples, not find-and-replace. A sentence that already reads natural stays. Match the smell, not the word.

## English Scenario

Eliminate predictable AI writing patterns. Write like a human: varied, imperfect, specific.

### Core Rules

1. **Cut filler phrases.** Remove throat-clearing openers, emphasis crutches, and adverbs that only signal emphasis. Keep adverbs that carry real meaning.
2. **Break formulaic structures.** Avoid binary contrasts, negative listings, dramatic fragmentation, rhetorical setups, false agency.
3. **Use active voice.** Every sentence needs a human subject doing something. No inanimate objects performing human actions (see False agency below).
4. **Be specific.** No vague declaratives ("The reasons are structural"). Name the specific thing. No lazy extremes ("every," "always," "never") doing vague work.
5. **Put the reader in the room.** No narrator-from-a-distance voice. "You" beats "People." Specifics beat abstractions.
6. **Vary rhythm.** Mix sentence lengths. Two items beat three. End paragraphs differently. No em dashes.
7. **Trust readers.** State facts directly. Skip softening, justification, hand-holding.
8. **Cut quotables.** If it sounds like a pull-quote, rewrite it.
9. **Do not replace one formula with another.** “Human” does not mean slangy, quirky, or performatively casual.
10. **No emoji.** Remove any emoji from the text being edited.

### Word Choice

Examples, not exhaustive -- any word used to signal importance rather than to say something is suspect.

**Overused emphasis adverbs (cut these when they only signal importance, not every adverb):**
"quietly", "deeply", "fundamentally", "remarkably", "arguably", "certainly", "really", "just", "literally", "genuinely", "honestly", "simply", "actually"

> NO: "quietly orchestrating workflows" / "fundamentally reshape how we think"
> OK: Say what it does. Drop the adverb.

**AI vocabulary: replace with plain language:**

| Avoid | Use instead |
|-------|-------------|
| delve (into) | examine, look at, explore |
| leverage (as verb) | use |
| utilize | use |
| robust | strong, reliable, solid |
| streamline | simplify, cut |
| harness | use, apply |
| navigate (challenges) | handle, address |
| unpack | explain, examine |
| paradigm | system, approach, model |
| synergy | combination, cooperation |
| ecosystem | community, network, field |
| tapestry | mix, combination |
| landscape | situation, field, area |
| game-changer | significant, important |
| deep dive | analysis, examination |
| moving forward | next, from now |

**Pompous copulas: use "is" instead:**
> NO: "serves as", "stands as", "marks", "represents"
> OK: "is"

### Sentence Structures to Avoid

Examples, not exhaustive -- any construction that performs insight rather than delivers it belongs here.

**Negative parallelism**: the single most common AI tell:
> NO: "It's not bold. It's backwards." / "Not because X, but because Y." / "The question isn't X. The question is Y."
> OK: State Y directly. Drop the negation entirely.

**Negative countdown:**
> NO: "Not a bug. Not a feature. A fundamental design flaw."
> OK: "It's a fundamental design flaw."

**Rhetorical self-questions:**
> NO: "The result? Devastating." / "The worst part? Nobody saw it coming."
> OK: State it: "The result was devastating."

**Anaphora abuse**: repeating the same sentence opener:
> NO: "They assume that... They assume that... They assume that..."
> OK: Combine or restructure. One statement, clear subject.

**Tricolon abuse**: rule of three, used three times back to back:
> NO: "Products impress people; platforms empower them. Products solve problems; platforms create worlds."
> OK: Make the point once, cleanly.

**False ranges:**
> NO: "From innovation to cultural transformation" (what's in between?)
> OK: List the two things directly, or pick one.

**Dramatic fragmentation**: manufactured emphasis via fragments:
> NO: "He published this. Openly. In a book. As a priest."
> OK: Complete sentences. Trust content over presentation.

**False agency**: inanimate objects performing human verbs:
> NO: "the complaint becomes a fix" / "the decision emerges" / "the data tells us"
> OK: Name the human. "Someone fixed it." "The team decided."

### Tone Patterns to Avoid

**False suspense transitions:**
> NO: "Here's the kicker." / "Here's the thing." / "Here's where it gets interesting."
> OK: Make the point. No buildup.

**Patronizing analogies:**
> NO: "Think of it like a highway system for data." / "Think of it as a Swiss Army knife."
> OK: Explain the concept directly. If an analogy helps, test it against three criteria before keeping it: (1) remove it and the paragraph collapses: it is load-bearing, not decorative; (2) push it one layer deeper and it still holds; (3) the reader gets it without further explanation. If it fails any of these, drop the analogy and state the idea directly.

**Futurist invitation:**
> NO: "Imagine a world where every tool you use has a quiet intelligence behind it..."
> OK: Describe what actually exists or what you're actually proposing.

**False vulnerability**: performative self-awareness:
> NO: "And yes, I'm openly in love with the platform model"
> OK: Real vulnerability is specific and uncomfortable. Skip the polish.

**Asserting simplicity instead of proving it:**
> NO: "The reality is simpler and less flattering" / "History is clear"
> OK: Show the evidence. Don't announce the conclusion before it.

**Grandiose stakes inflation:**
> NO: "This will fundamentally reshape how we think about everything." / "will define the next era of computing"
> OK: Say what it actually does.

**Pedagogical hand-holding:**
> NO: "Let's break this down step by step." / "Let's unpack what this really means."
> OK: Start with the content, not an announcement of the content.

**Vague attributions:**
> NO: "Experts argue..." / "Industry reports suggest..." / "Observers have cited..."
> OK: Name the expert, link the report, quote the person. If you can't, you don't have a source.

**Invented concept labels**: compound labels that sound analytical but aren't grounded:
> NO: "the supervision paradox" / "the acceleration trap" / "workload creep"
> OK: Describe the thing directly. Don't name it as if it's an established term.

### Paragraph & Composition Patterns to Avoid

**Short punchy fragments as paragraphs:**
> NO: "These weren't just products. And the software side matched. Then it professionalised."
> OK: Complete sentences. No staccato drama.

**Bold-first bullets**: every bullet starts with a bolded phrase:
> NO: "**Security**: Environment-based configuration..." / "**Performance**: Lazy loading..."
> OK: Write bullets as sentences, or drop the bold. Not every list needs labels.

**Fractal summaries**: "what I'm going to tell you; what I'm telling you; what I just told you":
> NO: "In this section, we'll explore... [3000 words later] ...as we've seen in this section."
> OK: Skip the preview and the recap. Write the content.
> Exception: a single closing sentence in a TL;DR that orients non-specialist readers to the structure ahead ("The rest of this piece follows X in order...") is intentional navigation, not a fractal summary. Keep it; flag it at most, but do not delete without author approval.

**Signposted conclusions:**
> NO: "In conclusion..." / "To sum up..." / "In summary..."
> OK: End. Don't announce that you're ending.

**The dead metaphor**: one metaphor used 10 times across a piece:
> NO: "The ecosystem needs ecosystems to build ecosystem value."
> OK: Use a metaphor once, then move on.

**Historical analogy stacking:**
> NO: "Apple didn't build Uber. Facebook didn't build Spotify. Stripe didn't build Shopify."
> OK: Make the point. One example is enough.

**One-point dilution**: same argument restated 10 ways across 4000 words:
> OK: Say it once. Add evidence or move on.

**"Despite its challenges..." formula:**
> NO: "Despite these challenges, the initiative continues to thrive."
> OK: Either address the challenges or don't raise them.

**It's worth noting / It bears mentioning:**
> NO: "It's worth noting that this approach has limitations." / "Notably," / "Importantly,"
> OK: Say the thing directly. Skip the announcement.

**Meta figure and diagram explanations:**
> NO: "This diagram lists the sensor stack of a humanoid robot. With it in view, the previous problems become easier to place."
> NO: "I made this diagram with ChatGPT Image2. Seeing the representations side by side makes the differences easier to grasp."
> NO: "This timeline shows the evolution... That is one of the reasons I find this field more interesting..."
> OK: The image or timeline itself. Let the surrounding judgment or personal project anchor carry the weight. Keep creation-process details only if they are themselves part of the story.

**List or classification intros:**
> NO: "Community data is an interesting piece. Diversity has to cover..."
> NO: "One detail is easy to miss. 'Output action' can mean..."
> OK: Go straight to the content: "Community data has a practical requirement: diversity has to cover..." or "Output action can mean different things..."

**Re-anchoring after cutting recaps (long-form articles):**
After removing table re-reads and structural repetition, scan the remaining prose for places where a general explanation can be tied back to the author's concrete project or experience already mentioned in the piece. This is one of the strongest ways to restore human voice in technical long-form writing.

---

**Bottom line: varied, imperfect, specific. Any single trope used once may be fine. The problem is when multiple appear together or one repeats.**
